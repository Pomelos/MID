package midcontainers.local;

import midcontainers.Binding;
import midcontainers.Container;
import midcontainers.ContainerException;
import midcontainers.Named;

public class LocalContainer implements Container {

    // TODO

}
